/*
works.js - unique passwords per button
- Put your sheet CSV export URL into SHEET_CSV_URL
- mapping controls which column pairs each button shows
*/

// list of distinct passwords for each of the 10 buttons (change as you like)
const PASSWORDS = [
  "zoheyr1989",
  "zoheyr1990",
  "zoheyr1991",
  "zoheyr1992",
  "zoheyr1993",
  "zoheyr1994",
  "zoheyr1989_7",
  "zoheyr1989_8",
  "zoheyr1989_9",
  "zoheyr1989_10"
];

// Replace with your published CSV URL (must be shared/published so it's publicly readable)
const SHEET_CSV_URL = "PUT_YOUR_SHEET_CSV_EXPORT_URL_HERE";

// mapping: for button index i, use columns mapping[i] = [colA_index, colB_index]
const mapping = [
  [0,1],
  [2,3],
  [4,5],
  [6,7],
  [8,9],
  [10,11],
  [12,13],
  [14,15],
  [16,17],
  [18,19]
];

function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  return lines.map(line => line.split(',').map(cell => cell.trim()));
}

async function fetchSheetData(){
  if(!SHEET_CSV_URL || SHEET_CSV_URL.includes("PUT_YOUR")) {
    throw new Error("Please set SHEET_CSV_URL in js/works.js to your sheet CSV export URL.");
  }
  const res = await fetch(SHEET_CSV_URL);
  if(!res.ok) throw new Error("Failed to fetch sheet: " + res.statusText);
  const txt = await res.text();
  return parseCSV(txt);
}

function showPrompt(index){
  const pwd = prompt("ادخل الرقم السري لعرض هذا العمل:");
  if(pwd === null) return; // cancelled
  const expected = PASSWORDS[index];
  if(pwd !== expected){
    alert("الرقم السري خاطئ.");
    return;
  }
  displayColumnsForIndex(index);
}

async function displayColumnsForIndex(index){
  const container = document.getElementById('result');
  container.innerHTML = "<em>جاري تحميل البيانات...</em>";
  try{
    const data = await fetchSheetData();
    const cols = mapping[index];
    if(!cols) { container.innerHTML = "خطأ في إعدادات الأعمدة."; return; }
    const [c1, c2] = cols;
    let html = "<table style='width:100%; border-collapse:collapse;'><thead><tr><th style='text-align:left;padding:6px;border-bottom:1px solid #ddd;'>العمود " + (c1+1) + "</th><th style='text-align:left;padding:6px;border-bottom:1px solid #ddd;'>العمود " + (c2+1) + "</th></tr></thead><tbody>";
    for(let i=0;i<data.length;i++){
      const row = data[i];
      const a = row[c1] || "";
      const b = row[c2] || "";
      html += "<tr><td style='padding:6px;border-bottom:1px solid #f0f0f0;'>" + escapeHtml(a) + "</td><td style='padding:6px;border-bottom:1px solid #f0f0f0;'>" + escapeHtml(b) + "</td></tr>";
    }
    html += "</tbody></table>";
    container.innerHTML = html;
  }catch(err){
    container.innerHTML = "<span style='color:#b00;'>خطأ في جلب البيانات: " + escapeHtml(err.message) + "</span>";
  }
}

function escapeHtml(s){
  return String(s).replace(/[&<>"]/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[m]; });
}

document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.work-btn').forEach(btn=>{
    btn.addEventListener('click', function(){ showPrompt(parseInt(btn.dataset.index)); });
  });
});
